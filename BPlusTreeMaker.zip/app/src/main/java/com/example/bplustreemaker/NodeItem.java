package com.example.bplustreemaker;

class NodeItem {
    private String levelData;

    NodeItem(String levelData) {
        this.levelData = levelData;
    }

    String getLevelData() {
        return this.levelData;
    }
}
