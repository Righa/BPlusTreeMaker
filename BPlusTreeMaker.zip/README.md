# B+ Tree Maker
android app to create b+ trees
<hr>
<strong>1. </strong> To construct a b+ tree, first enter the order of the tree you would like to construct. <br>
<strong>2. </strong> Then on the new screen, type in values on the enter values field and press insert. <br>
<strong> - </strong> the values enclosed with '|x,x,x|' are the nodes of your tree. <br>
<strong> - </strong> you may transfer the values to a paper for a better visual impression. <br>
